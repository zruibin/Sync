/* Code shared with vgdb server. We'll include server.h here first to define
   magic macros for libc functions used. */
#include "server.h"
#include "remote-utils-shared.c"

/* Note all code is in remote-utils-shared.c included above.  */
