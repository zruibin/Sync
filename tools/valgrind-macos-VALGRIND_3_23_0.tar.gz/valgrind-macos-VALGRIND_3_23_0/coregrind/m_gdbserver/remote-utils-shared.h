#ifndef REMOTE_UTILS_SHARED_H
#define REMOTE_UTILS_SHARED_H

extern int tohex (int nib);
extern int hexify (char *hex, const char *bin, int count);

#endif /* REMOTE_UTILS_SHARED_H */
